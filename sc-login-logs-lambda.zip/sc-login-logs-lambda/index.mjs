// Updated ECMAScript module code
import AWS from 'aws-sdk';

export const handler = async (event, context) => {
    //console.log('Received event:', JSON.stringify(event, null, 2));
    console.log(event.Records[0].dynamodb);
    // Configure AWS region and SES
    AWS.config.update({region: 'us-east-1'});
    const ses = new AWS.SES({apiVersion: '2010-12-01'});

    try {
        // Extract necessary data from the event (DynamoDB record)
        const {id, logintime, success, username,email} = event.Records[0].dynamodb.NewImage;
        console.log(event);
        // Specify the recipient email address
        const recipientEmail = 'ranasl62@gmail.com';

        // Compose the email message
        const emailSubject = `Login Alert for User ${username.S}`;
        const emailMessage = `User ${username.S} logged in at ${logintime.S} with success: ${success.BOOL}`;

        // Define the email parameters
        const params = {
            Source: 'mdrana.hossain@miu.edu', // Replace with your verified sender email address in SES
            Destination: {
                ToAddresses: [recipientEmail],
            },
            Message: {
                Subject: {
                    Data: emailSubject,
                },
                Body: {
                    Text: {
                        Data: emailMessage,
                    },
                },
            },
        };

        // Send the email using SES
        const result = await ses.sendEmail(params).promise();
        console.log('Email sent:', result);
    } catch (error) {
        console.error('Error sending email:', error);
    }
};
